ScrollReveal().reveal('.title-a', {
    duration: 1000,
    origin: 'left',
    distance: '20px',
    reset: true,
    delay: 200,
});'.intro-title',

ScrollReveal().reveal('.col-md-4', {
    duration: 1000,
    origin: 'bottom',
    distance: '20px',
    reset: true,
    delay: 200,
});